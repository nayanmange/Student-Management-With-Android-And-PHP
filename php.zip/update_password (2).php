<?php
	require "connection.php";
	
	$username = $_POST["phone"];
	$password = $_POST["password"];
		
	$query = "UPDATE users SET password='$password' WHERE phone='$username'";
	$result = mysqli_query($con,$query);
	
	if($result)
	{
		$result1=1;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	else
	{
		$result1=0;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
?>