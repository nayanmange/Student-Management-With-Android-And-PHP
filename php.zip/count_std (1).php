<?php
	require "connection.php";
	
		
	$query = "select count(id) from std";
	
	$result = mysqli_query($con,$query);
	
	
	if(mysqli_num_rows($result)>0)
	{
	    
	   	$result3 = array();
	   	
	   	$res = mysqli_fetch_array($result);
	   
	    $result3[]=array("sessionID"=>"1");
            $result3[] = array(
            "count"=>$res[0]
            );
        header('Content-type: application/json');
        echo json_encode(['result'=>$result3]);
		exit();
	}
	else
	{
		$result1=0;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
?>