<?php

	$server="localhost";
	$username="id17330635_stu";
	$password="1Q2w3e4r@123";
	$dbname="id17330635_student";
	
	$con=mysqli_connect($server,$username,$password,$dbname);
?>