<?php 
	require "connection.php";
	
	$name = $_POST["name"];
	$des = $_POST["des"];
	$datec = $_POST["datec"];
	

	
	$query = "INSERT INTO std (name,des,datec) VALUES ('$name','$des','$datec')";
	
	$result = mysqli_query($con,$query);

			
	if($result)
	{

		$result1=1;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	else
	{
		$result1=0;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	

?>