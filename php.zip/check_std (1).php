<?php 
	require "connection.php";
	
	$name = $_POST["name"];
	
	
	$query = "select * from std where name = '$name'";
	
	$result = mysqli_query($con,$query);
			
	if(mysqli_num_rows($result)>0)
	{
		$result1=0;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	else
	{
		$result1=1;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
?>