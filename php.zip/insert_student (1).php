<?php 
	require "connection.php";
	
	$name = $_POST["name"];
	$gender = $_POST["gender"];
	$bdate = $_POST["birthdate"];
	$contact = $_POST["contact"];
	$email = $_POST["email"];
	$std = $_POST["std"];
	$div = $_POST["div"];
	$datec = $_POST["datec"];
	
	
	$query = "INSERT INTO `student`(`name`, `gender`, `birthdate`, `contact`, `email`, `std`, `div`, `datec`) VALUES('$name','$gender','$bdate','$contact','$email','$std','$div','$datec')";
	
	$result = mysqli_query($con,$query);
			
	if($result)
	{
		$result1=1;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	else
	{
		$result1=0;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	

?>