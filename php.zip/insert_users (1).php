<?php 
	require "connection.php";
	
	$name = $_POST["name"];
	$surname = $_POST["surname"];
	$email = $_POST["email"];
	$phone = $_POST["phone"];
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	
	$query = "INSERT INTO users(name,surname,email,phone,username,password) 
	VALUES('$name','$surname','$email','$phone','$username','$password')";
	
	$result = mysqli_query($con,$query);
			
	if($result)
	{
		$result1=1;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	else
	{
		$result1=0;
		$result2["sessionID"] = $result1;
		header('Content-type: application/json');
		echo json_encode($result2);
		exit();
	}
	

?>